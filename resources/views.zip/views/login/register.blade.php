<form action="{{ route('register.post') }}" method="POST">
    @csrf

    <input
        type="text"
        name="name"
        value="{{ old('name') }}"
        placeholder="Tên"
        required
    >

    <input
        type="email"
        name="email"
        value="{{ old('email') }}"
        placeholder="Email"
        required
    >

    <input
        type="password"
        name="password"
        placeholder="Mật khẩu"
        required
    >

    <input
        type="password"
        name="password_confirmation"
        placeholder="Nhập lại mật khẩu"
        required
    >

    <button type="submit">Đăng ký</button>
</form>
