<h2>Thêm sản phẩm</h2>

<form action="{{ route('admin.products.store') }}" method="POST">
    @csrf

    <input type="text" name="name" placeholder="Tên sản phẩm">
    <br><br>

    <input type="number" name="price" placeholder="Giá">
    <br><br>

    <textarea name="description" placeholder="Mô tả"></textarea>
    <br><br>

    <button>Thêm</button>
</form>
