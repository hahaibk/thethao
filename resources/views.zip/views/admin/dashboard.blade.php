<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; padding: 20px; }
        .stats { display: flex; gap: 20px; }
        .box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            width: 200px;
            box-shadow: 0 0 5px rgba(0,0,0,.1);
        }
        table {
            width: 100%;
            background: white;
            margin-top: 30px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        th { background: #eee; }
    </style>
</head>
<body>

<h1>ADMIN DASHBOARD</h1>
<p>Xin chào {{ auth()->user()->name }}</p>

<div class="stats">
    <div class="box">
        <h3>Sản phẩm</h3>
        <strong>{{ $totalProducts }}</strong>
    </div>

    <div class="box">
        <h3>Danh mục</h3>
        <strong>{{ $totalCategories }}</strong>
    </div>

    <div class="box">
        <h3>User</h3>
        <strong>{{ $totalUsers }}</strong>
    </div>

    <div class="box">
        <h3>Tồn kho</h3>
        <strong>{{ $totalStock }}</strong>
    </div>
</div>

<h2>Sản phẩm sắp hết hàng</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Tên</th>
        <th>Tồn kho</th>
    </tr>

    @forelse ($lowStockProducts as $product)
        <tr>
            <td>{{ $product->id }}</td>
            <td>{{ $product->name }}</td>
            <td>{{ $product->totalStock() }}</td>
        </tr>
    @empty
        <tr>
            <td colspan="3">Không có sản phẩm sắp hết</td>
        </tr>
    @endforelse
</table>

</body>
</html>
