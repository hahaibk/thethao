<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>

<h1>Trang Admin</h1>

<a href="{{ route('admin.products.create') }}">➕ Thêm sản phẩm</a>

<form action="{{ route('logout') }}" method="POST">
    @csrf
    <button>Đăng xuất</button>
</form>

</body>
</html>
